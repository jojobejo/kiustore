<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        verify_session('admin');

        $this->load->model(array(
            'customer_model' => 'customer',
            'order_model' => 'order',
            'salesman_model' => 'salesman',
            'payment_model' => 'payment',
            'rajaongkir_model' => 'ongkirapi',
            'admin_model' => 'users'
        ));
        $this->load->library('form_validation');

        if (admin_role() != 'admin') {
            show_error('Anda tidak memiliki akses untuk mengelola akun internal.', 403, 'Akses ditolak');
        }
    }

    public $api_key = "197f7e1329685d3ed9d1468c54efc9dd";

    public function index()
    {
        $params['title'] = 'Admin';
        $data['roles'] = $this->users->get_role_options();

        $this->load->view('header', $params);
        $this->load->view('admin/admin', $data);
        $this->load->view('footer');
    }

    public function add_new_admin()
    {
        $params['title'] = 'Tambah User Baru';

        $user['flash'] = $this->session->flashdata('add_new_user_flash');
        //  $user['salesman'] = $this->salesman->get_all_salesman();
        // print_r($customer);exit;
        $this->load->view('header', $params);
        $this->load->view('admin/add_new', $user);
        $this->load->view('footer');
    }

    public function add_admin()
    {
        $this->form_validation->set_error_delimiters('<div class="form-error text-danger font-weight-bold">', '</div>');

        $this->form_validation->set_rules('name', 'Nama', 'trim|required|min_length[4]|max_length[255]');
        $this->form_validation->set_rules('email', 'email', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            // print_r(validation_errors());exit;
            $this->add_new_admin();
        } else {
            $password = $this->input->post('password');
            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $role = $this->input->post('role');
            $status = $this->input->post('status');
            $is_internal = $this->input->post('is_internal') ? 1 : 0;

            $password = password_hash($password, PASSWORD_BCRYPT);

            $data = array(
                'password' => $password,
                'name' => $name,
                'email' => $email,
                'role' => $role,
                'register_date' => date('Y-m-d H:i:s'),
                'status' => $status,
                'is_internal' => $is_internal
            );

            $this->users->register_user($data);
            $this->session->set_flashdata('add_new_user_flash', 'User berhasil ditambahkan!');

            redirect('admin/admin');
        }
    }

    public function view($id = 0)
    {
        if ($this->customer->is_customer_exist($id)) {
            $data = $this->customer->customer_data($id);

            $params['title'] = $data->name;

            $customer['customer'] = $data;
            $customer['flash'] = $this->session->flashdata('customer_flash');
            $customer['orders'] = $this->order->order_by($id);
            $customer['payments'] = $this->payment->payment_by($id);

            $this->load->view('header', $params);
            $this->load->view('customers/view', $customer);
            $this->load->view('footer');
        } else {
            show_404();
        }
    }

    public function edit($id = 0)
    {
        if ($this->users->is_users_exist($id)) {
            $data = $this->users->users_data($id);

            $params['title'] = 'Edit ' . $data->name;

            $users['flash'] = $this->session->flashdata('edit_users_flash');
            $users['users'] = $data;

            $this->load->view('header', $params);
            $this->load->view('admin/admin/edit', $users);
            $this->load->view('footer');
        } else {
            show_404();
        }
    }

    public function edit_users()
    {
        $this->form_validation->set_error_delimiters('<div class="form-error text-danger font-weight-bold">', '</div>');

        $this->form_validation->set_rules('name', 'Nama sales', 'trim|required|min_length[4]|max_length[255]');

        if ($this->form_validation->run() == FALSE) {
            $id = $this->input->post('id');
            $this->edit($id);
        } else {
            $id = $this->input->post('id');
            $data = $this->users->users_data($id);
            $current_picture = $data->profile_picture;

            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $role = $this->input->post('role');
            $is_internal = $this->input->post('is_internal') ? 1 : 0;

            $config['upload_path'] = './assets/uploads/users/';
            $config['allowed_types'] = 'jpg|png|jpeg';
            $config['max_size'] = 2048;

            $this->load->library('upload', $config);

            if (isset($_FILES['picture']) && @$_FILES['picture']['error'] == '0') {
                if ($this->upload->do_upload('picture')) {
                    $upload_data = $this->upload->data();
                    $new_file_name = $upload_data['file_name'];

                    if ($this->users->is_users_have_image($id)) {
                        $file = './assets/uploads/users/' . $current_picture;

                        $file_name = $new_file_name;
                        unlink($file);
                    } else {
                        $file_name = $new_file_name;
                    }
                } else {
                    show_error($this->upload->display_errors());
                }
            } else {
                $file_name = ($this->users->is_users_have_image($id)) ? $current_picture : NULL;
            }

            $users['name'] = $name;
            $users['email'] = $email;
            $users['role'] = $role;
            $users['is_internal'] = $is_internal;
            //  $users['status'] = $status;

            if ($password !== '') {
                $users['password'] = password_hash($password, PASSWORD_BCRYPT);
            }

            $this->users->edit_users($id, $users);
            $this->session->set_flashdata('edit_users_flash', 'User berhasil diperbarui!');

            redirect('admin/admin/edit/' . $id);
        }
    }

    public function api($action = '')
    {
        switch ($action) {
            case 'users':
                $filters = array(
                    'role' => $this->input->get('role', true),
                    'is_internal' => $this->input->get('is_internal', true)
                );

                $users = $this->users->get_all_users($filters);

                //  $n = 0;
                //  foreach ($users as $user)
                //  {
                //      $users[$n]->profile_picture = base_url('assets/uploads/users/'. $customer->profile_picture);

                //      $n++;
                //  }

                $users['data'] = $users;

                $response = $users;
                break;
            case 'toggle_internal':
                $id = $this->input->post('id');
                $is_internal = $this->input->post('is_internal') ? 1 : 0;

                $updated = $this->users->update_internal_status($id, $is_internal);

                $response = array(
                    'code' => $updated ? 200 : 422,
                    'is_internal' => $is_internal
                );
                break;
            case 'delete':
                $id = $this->input->post('id');

                $this->users->delete_user($id);

                $response = array('code' => 204);
                break;
            case 'deactivate':
                $id = $this->input->post('id');

                $this->users->deactivate_user($id);

                $response = array('code' => 204);
                break;
            case 'activate':
                $id = $this->input->post('id');

                $this->users->activate_user($id);

                $response = array('code' => 204);
                break;
        }

        $response = json_encode($response);
        $this->output->set_content_type('application/json')
            ->set_output($response);
    }

    public function dev_ongkir()
    {
        $params['title'] = "Edit";


        $this->load->view('header', $params);
        $this->load->view('admin/admin/dev_ongkir');
        $this->load->view('footer');
    }

    public function ajax_provinces()
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://pro.rajaongkir.com/api/province",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded",
                "key: " . $this->api_key,
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);

        if ($response) {
            $data = json_decode($response, true);
            $provinces = [];
            if (isset($data['rajaongkir']['results'])) {
                foreach ($data['rajaongkir']['results'] as $prov) {
                    $provinces[] = [
                        "id" => $prov['province_id'],
                        "text" => $prov['province']
                    ];
                }
            }
            echo json_encode($provinces);
        } else {
            echo json_encode([]);
        }
    }


    public function ajax_cities()
    {
        $province_id = $this->input->post('province_id');

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://pro.rajaongkir.com/api/city?province={$province_id}",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ["key:" . $this->api_key],
        ]);
        $res = json_decode(curl_exec($curl), true);
        curl_close($curl);

        echo json_encode($res['rajaongkir']['results']);
    }
    public function ajax_subdistricts()
    {
        $city_id = $this->input->post('city_id');

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://pro.rajaongkir.com/api/subdistrict?city={$city_id}",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ["key:" . $this->api_key],
        ]);
        $res = json_decode(curl_exec($curl), true);
        curl_close($curl);

        echo json_encode($res['rajaongkir']['results']);
    }


    public function ajax_hitung_ongkir()
    {
        $destination = $this->input->post('kec_id');
        $courier     = $this->input->post('courier');
        $weight      = (int) $this->input->post('weight');

        if ($destination == '' || $courier == '' || $weight <= 0) {
            echo json_encode(['status' => 'error']);
            return;
        }

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://pro.rajaongkir.com/api/cost",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => http_build_query([
                'origin' => "2528",
                'originType' => 'subdistrict',
                'destination' => $destination,
                'destinationType' => 'subdistrict',
                'weight' => $weight,
                'courier' => $courier
            ]),
            CURLOPT_HTTPHEADER => [
                "content-type: application/x-www-form-urlencoded",
                "key:" . $this->api_key
            ],
        ]);

        $response = curl_exec($curl);
        curl_close($curl);

        $res = json_decode($response, true);

        $results = $res['rajaongkir']['results'] ?? [];

        $hasCost = false;
        foreach ($results as $r) {
            if (!empty($r['costs'])) {
                $hasCost = true;
                break;
            }
        }

        if (!$hasCost) {
            echo json_encode([
                'status' => 'empty',
                'message' => 'Layanan tidak tersedia',
                'data' => []
            ]);
            return;
        }

        echo json_encode([
            'status' => 'success',
            'weight' => $weight,
            'data'   => $results
        ]);
    }
}
