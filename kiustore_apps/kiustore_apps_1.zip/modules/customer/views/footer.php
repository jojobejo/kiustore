<?php
defined('BASEPATH') or exit('No direct script access allowed');
$controller = $this->router->fetch_class();
$is_product_detail = ($this->uri->segment(1) === 'product' && is_numeric($this->uri->segment(2)) && $this->uri->segment(3));
?>
<!-- <div class="footer-wrap shop notif-cart" id="notif-cart">
  <ul class="footer">
    <li class="footer-item"> <span class="font-xs">1 Barang berhasil ditambahkan ke keranjang belanja</span></li>
    <li class="footer-item">
      <a href="cart.html" class="font-sm">Cek Keranjang Belanja <i data-feather="chevron-right"></i></a>
    </li>
  </ul>
</div> -->

<div class="internet-connection-status" id="internetStatus"></div>

<!-- Footer Start -->
<?php if ($is_product_detail) : ?>
  <style>
    .footer-wrap.footer-fixed-product {
      position: fixed;
      left: 0;
      right: 0;
      bottom: 0;
      z-index: 3;
    }

    .main-wrap.product-page {
      padding-bottom: 90px;
    }
  </style>
<?php endif; ?>
<footer class="footer-wrap <?= $is_product_detail ? 'footer-fixed-product' : ''; ?>" style="background-color: #0c5fdb;">
  <ul class="footer">
    <li class="footer-item <?= ($this->uri->segment(1) == 'home' ? 'active' : '') ?>">
      <a href="<?= site_url('home') ?>" class="footer-link" data-tour="footer-home">
        <i class="iconly-Home icli"></i>
        <span>Beranda</span>
      </a>
    </li>
    <li class="footer-item <?= ($this->uri->segment(1) == 'category' ? 'active' : '') ?>">
      <a href="<?= site_url('category') ?>" class="footer-link" data-tour="footer-category">
        <i class="iconly-Category icli"></i>
        <span>Kategori</span>
      </a>
    </li>
    <li class="footer-item <?= ($this->uri->segment(1) == 'cart' ? 'active' : '') ?>">
      <a href="<?= site_url('cart') ?>" class="footer-link" data-tour="footer-cart">
        <i class="iconly-Bag-2 icli"></i>
        <span>Keranjang</span>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="cart_sum">0 </span>
      </a>
    </li>
    <li class="footer-item <?= ($this->uri->segment(1) == 'order_history' ? 'active' : '') ?>">
      <a href="<?= site_url('order_history') ?>" class="footer-link" data-tour="footer-history">
        <i class="iconly-Paper icli"></i>
        <span class="offer">Riwayat</span>
      </a>
    </li>
    <li class="footer-item <?= ($this->uri->segment(1) == 'message' ? 'active' : '') ?>">
      <a href="<?= site_url('message') ?>" class="footer-link" data-tour="footer-chat">
        <i class="iconly-Chat icli"></i>
        <span>Chat</span>
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="unread_sum">0 </span>
      </a>
    </li>
  </ul>
</footer>
<!-- Footer End -->

<audio id="customer_message_notification_audio" src="<?php echo base_url('assets/audio/order2.mp3'); ?>" preload="auto"></audio>

<!-- Bootstrap Js -->
<script src="<?php echo get_theme_uri('js/bootstrap.bundle.min.js'); ?>"></script>

<!-- Lord Icon -->
<script src="<?php echo get_theme_uri('js/lord-icon-2.1.0.js'); ?>"></script>

<!-- Feather Icon -->
<script src="<?php echo get_theme_uri('js/feather.min.js'); ?>"></script>

<!-- Slick Slider js -->
<script src="<?php echo get_theme_uri('js/slick.js'); ?>"></script>
<script src="<?php echo get_theme_uri('js/slick.min.js'); ?>"></script>
<script src="<?php echo get_theme_uri('js/slick-custom.js'); ?>"></script>

<!-- Swiper Js -->
<!-- <script src="<?php echo get_theme_uri('js/jquery-swipe-1.11.3.min.js'); ?>""></script>
    <script src="<?php echo get_theme_uri('js/jquery.mobile-1.4.5.min.js'); ?>""></script> -->

<!-- Script js -->
<script src="<?php echo get_theme_uri('js/script.js'); ?>"></script>

<script src="<?php echo get_theme_uri('js/bs5-toast.min.js'); ?>"></script>
<script src="<?php echo site_url('assets/js/offline.js'); ?>"></script>
<script>
  window.WEBVIEW_ERROR_CONFIG = {
    noInternetUrl: '<?php echo site_url('error/no-internet'); ?>',
    appErrorUrl: '<?php echo site_url('error/app'); ?>',
    notifyElementId: 'internetStatus',
    timeoutMs: 20000,
    captureRuntimeErrors: false,
    captureAjax5xx: false,
    onlyWebView: true
  };
</script>
<script src="<?php echo site_url('assets/js/webview-error-handler.js?v=20260225_2'); ?>"></script>
<script src="<?php echo base_url('assets/js/kiu-splash.js?v=20260825_1'); ?>"></script>


<script>
  if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
  }
</script>

<?php if (!empty($_SESSION['__ACTIVE_SESSION_DATA'])) : ?>
  <script>
    var customerUnreadMessageTotal = null;
    var customerMessageAudioUnlocked = false;

    function requestCustomerMessageNotificationPermission() {
      if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
      }
    }

    function unlockCustomerMessageAudio() {
      if (customerMessageAudioUnlocked) {
        return;
      }

      var audio = document.getElementById('customer_message_notification_audio');
      if (!audio) {
        return;
      }

      audio.muted = true;
      var playPromise = audio.play();

      if (playPromise && playPromise.then) {
        playPromise.then(function() {
          audio.pause();
          audio.currentTime = 0;
          audio.muted = false;
          customerMessageAudioUnlocked = true;
        }).catch(function() {
          audio.muted = false;
        });
      } else {
        audio.muted = false;
        customerMessageAudioUnlocked = true;
      }
    }

    function playCustomerMessageNotificationSound() {
      var audio = document.getElementById('customer_message_notification_audio');
      if (!audio) {
        return;
      }

      audio.muted = false;
      audio.currentTime = 0;
      var playPromise = audio.play();

      if (playPromise && playPromise.catch) {
        playPromise.catch(function() {});
      }
    }

    function showCustomerUnreadMessageNotification(totalUnread) {
      playCustomerMessageNotificationSound();

      if (!('Notification' in window)) {
        return;
      }

      if (Notification.permission === 'granted') {
        var notify = new Notification('Pesan Baru - Karisma Online', {
          body: 'Anda memiliki ' + totalUnread + ' pesan belum dibaca',
          icon: '<?php echo site_url('assets/images/favicon.png'); ?>'
        });

        notify.onclick = function(event) {
          event.preventDefault();
          window.location.href = '<?php echo site_url('message'); ?>';
        };
      } else if (Notification.permission === 'default') {
        Notification.requestPermission();
      }
    }

    function refreshCustomerUnreadMessages(allowNotify) {
      $.ajax({
        method: 'GET',
        url: '<?php echo site_url('count_unread_messages'); ?>',
        success: function(res) {
          var unread = parseInt(res, 10) || 0;

          $('#unread_sum').text(unread);

          if (allowNotify && customerUnreadMessageTotal !== null && unread > customerUnreadMessageTotal) {
            showCustomerUnreadMessageNotification(unread);
          }

          customerUnreadMessageTotal = unread;
        }
      });
    }

    $(document).one('click touchstart keydown', function() {
      requestCustomerMessageNotificationPermission();
      unlockCustomerMessageAudio();
    });

    //Total Product in Cart
    $.ajax({
      method: 'GET',
      url: '<?php echo site_url('cart_api?action=cart_info'); ?>',
      success: function(res) {
        var data = res.data;

        var total_item = data.total_item;
        $('#cart_sum').text(total_item);
        $('.cart-item-total').text(total_item);
      }
    });

    //Total Unread Message
    refreshCustomerUnreadMessages(false);
    setInterval(function() {
      refreshCustomerUnreadMessages(true);
    }, 5000);
  </script>
<?php endif; ?>

<script>
  function send_message() {
    // e.preventDefault();
    var message = $("#pesan").val();
    $.ajax({
      url: base_url + 'message/send',
      type: 'POST',
      dataType: 'json',
      data: {
        message: message
      },
      success: function(data) {
        console.log(data);
      },
      error: function() {
        console.log(data);
      },
    });
  }
  // $("#send_message").submit(function(e) {

  // });

  $('#atc').click(function(e) {
    e.preventDefault();
    var id = $(this).data('id');
    var sku = $(this).data('sku');
    var qty = $(this).attr('data-qty');
    qty = (qty > 0) ? qty : 1;
    var price = $(this).data('price');
    var name = $(this).data('name');
    var satuan = $(this).data('satuan');
    var satuan_text = $(this).data('satuan-text');
    var satuan_qty = $(this).data('satuan-qty');
    var product_type = $(this).data('product-type');
    var product_weight = $(this).data('product-weight');

    $.ajax({
      method: 'POST',
      url: '<?php echo site_url('cart_api?action=add_item'); ?>',
      data: {
        id: id,
        sku: sku,
        qty: qty,
        satuan: satuan,
        satuan_text: satuan_text,
        satuan_qty: satuan_qty,
        price: price,
        name: name,
        product_type: product_type,
        product_weight: product_weight
      },
      success: function(res) {
        if (res.code == 200) {
          var totalItem = res.total_item;
          $('#cart_sum').text(totalItem);
          $('.cart-item-total').text(totalItem);
          $("#myToast").toast("show");
          // toastr.info('Item ditambahkan dalam keranjang');
          new bs5.Toast({
            body: 'Berhasil menambahkan barang ke keranjang belanja',
            autohide: true,
            animation: true,
            btnCloseWhite: true,
            className: 'border-0 bg-success text-white',
            delay: 2000,
          }).show();
        } else if (res.code == 201) {
          window.location.replace(base_url + "login");
        } else if (res.code == 202) {
          console.log(qty);
          new bs5.Toast({
            body: res.message,
            autohide: true,
            animation: true,
            btnCloseWhite: true,
            className: 'border-0 bg-danger text-white',
            delay: 2000,
          }).show();
        } else {
          console.log('Terjadi kesalahan');
        }
      }
    });
  });

  $('#cekongkir').click(function(e) {
    e.preventDefault();
    var id = $(this).data('id');
    var sku = $(this).data('sku');
    var qty = $(this).attr('data-qty');
    qty = (qty > 0) ? qty : 1;
    var price = $(this).data('price');
    var name = $(this).data('name');
    var satuan = $(this).data('satuan');
    var satuan_text = $(this).data('satuan-text');
    var satuan_qty = $(this).data('satuan-qty');
    var product_type = $(this).data('product-type');
    var product_weight = $(this).data('product-weight');

    $.ajax({
      method: 'POST',
      url: '<?php echo site_url('cart_api?action=cekongkir'); ?>',
      data: {
        id: id,
        sku: sku,
        qty: qty,
        satuan: satuan,
        satuan_text: satuan_text,
        satuan_qty: satuan_qty,
        price: price,
        name: name,
        product_type: product_type,
        product_weight: product_weight
      },
      success: function(res) {
        if (res.code == 200) {
          var totalItem = res.total_item;
          $('#cart_sum').text(totalItem);
          $('.cart-item-total').text(totalItem);
          $("#myToast").toast("show");
          // toastr.info('Item ditambahkan dalam keranjang');
          new bs5.Toast({
            body: 'Berhasil menambahkan barang ke keranjang belanja',
            autohide: true,
            animation: true,
            btnCloseWhite: true,
            className: 'border-0 bg-success text-white',
            delay: 2000,
          }).show();
        } else if (res.code == 201) {
          window.location.replace(base_url + "login");
        } else if (res.code == 202) {
          console.log(qty);
          new bs5.Toast({
            body: res.message,
            autohide: true,
            animation: true,
            btnCloseWhite: true,
            className: 'border-0 bg-danger text-white',
            delay: 2000,
          }).show();
        } else {
          console.log('Terjadi kesalahan');
        }
      }
    });
  });


  $('.cart-update').on("input", function(e) {
    e.preventDefault();

    var rowid = $(this).data('rowid');
    var qty = $(this).val();

    // $('.product-name', tr).html('<i class="fa fa-spin fa-spinner"></i> Menghapus...');

    $.ajax({
      method: 'POST',
      url: '<?php echo site_url('cart_api?action=update_item'); ?>',
      data: {
        rowid: rowid,
        qty: qty
      },
      success: function(res) {
        if (res.error == 0) {
          // tr.addClass('alert alert-danger');
          $('.qty-item-' + rowid + '').text(qty);
          $('.qty-item-' + id + '').text(qty);
          $('.subtotal-item-' + rowid + '').text(res.item.subtotal);

          $('.n-subtotal').text(res.total.subtotal);
          $('.n-ongkir').text(res.total.ongkir);
          $('.n-total').text(res.total.total);
        }
      }
    })
  });

  $('.delete-button').click(function(e) {
    e.preventDefault();

    var rowid = $(this).data('rowid');
    var brid = $(this).data('brid');

    var cart_list = $('.cart-' + rowid);
    // $('.product-name', tr).html('<i class="fa fa-spin fa-spinner"></i> Menghapus...');

    $.ajax({
      method: 'POST',
      url: '<?php echo site_url('cart_api?action=remove_item'); ?>',
      data: {
        rowid: rowid,
        brid: brid
      },
      success: function(res) {
        if (res.code == 204) {
          setTimeout(function(e) {
            cart_list.hide('fade');

            $('.n-subtotal').text(res.total.subtotal);
            $('.n-ongkir').text(res.total.ongkir);
            $('.n-total').text(res.total.total);
          }, 500);
        }
        if (res.total.total_item == 0) {
          var div = '<main class="main-wrap empty-cart mb-xxl">' +
            '<div class="banner-box">' +
            '<img src="<?php echo get_theme_uri('svg/empty-cart.svg'); ?>" class="img-fluid" alt="404" />' +
            '</div>' +
            '<section class="error mb-large">' +
            '<h2 class="font-lg">Keranjang belanja anda kosong</h2>' +
            '<a href="<?php echo site_url('category'); ?>" class="btn-solid">Mulai Belanja</a>' +
            '</section>' +
            '</main>';
          setTimeout(function(e) {
            $('.cart-page').replaceWith(div).show('fade');
          }, 1000);
        }
      }
    })
  });

  $('#qty').change(function(e) {
    e.preventDefault();
    var val = $(this).val();
    $('#atc').attr('data-qty', val);
  });

  $('#satuan').change(function(e) {
    e.preventDefault();
    var val = $(this).val();
    var text = $("#satuan option:selected").text();
    $('#atc').attr('data-satuan', val);
    $('#atc').attr('data-satuan-text', text);
  });

  function update_item(rowid, qty) {
    if (qty == 0) {
      $('.qty-item-' + rowid + '').text(qty);
    } else {
      $.ajax({
        method: 'POST',
        url: '<?php echo site_url('cart_api?action=update_item'); ?>',
        data: {
          rowid: rowid,
          qty: qty
        },
        success: function(res) {
          if (res.error == 0) {
            // tr.addClass('alert alert-danger');
            $('.qty-item-' + rowid + '').text(qty);
            $('.subtotal-item-' + rowid + '').text(res.item.subtotal);

            $('.n-subtotal').text(res.total.subtotal);
            $('.n-ongkir').text(res.total.ongkir);
            $('.n-total').text(res.total.total);
          }
        }
      })
    }

  };





  $('.adds').on('click', function() {
    if ($(this).prev().val() < 100) {
      $(this).prev().val(+$(this).prev().val() + 1);
      update_item($(this).prev().data('rowid'), +$(this).prev().val());
    }
  });
  $('.subs').on('click', function() {
    if ($(this).next().val() > 1) {
      if ($(this).next().val() > 1) $(this).next().val(+$(this).next().val() - 1);
      update_item($(this).next().data('rowid'), +$(this).next().val());
    }
  });
</script>

</script>
</body>
<!-- Body End -->

</html>
